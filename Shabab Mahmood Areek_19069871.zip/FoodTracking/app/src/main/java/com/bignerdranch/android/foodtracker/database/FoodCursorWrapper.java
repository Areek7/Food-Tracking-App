package com.bignerdranch.android.foodtracker.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.bignerdranch.android.foodtracker.Food;

import java.util.Date;
import java.util.UUID;

public class FoodCursorWrapper extends CursorWrapper {
    public FoodCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public Food getFood(){
        String uuidString = getString(getColumnIndex(FoodDbSchema.FoodTable.Cols.UUID));
        String title = getString(getColumnIndex(FoodDbSchema.FoodTable.Cols.TITLE));
        String info = getString(getColumnIndex(FoodDbSchema.FoodTable.Cols.INFO));
        long date = getLong(getColumnIndex(FoodDbSchema.FoodTable.Cols.DATE));
        int isSolved = getInt(getColumnIndex(FoodDbSchema.FoodTable.Cols.SOLVED));
        String suspect = getString(getColumnIndex(FoodDbSchema.FoodTable.Cols.SUSPECT));

        Food food = new Food(UUID.fromString(uuidString));
        food.setTitle(title);
        food.setInfo(info);
        food.setDate(new Date(date));
        food.setSolved(isSolved !=0);
        food.setSuspect(suspect);

        return food;
    }
}