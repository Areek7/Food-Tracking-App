package com.bignerdranch.android.foodtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.bignerdranch.android.foodtracker.database.FoodBaseHelper;
import com.bignerdranch.android.foodtracker.database.FoodCursorWrapper;
import com.bignerdranch.android.foodtracker.database.FoodDbSchema;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// Singleton to store one instance of the Food Lab
public class FoodLab {
    private static FoodLab sFoodLab;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    // Create Singleton
    public static FoodLab get(Context context){
        // If the singleton doesn't exist yet, create it.
        if(sFoodLab == null){
            // Don't assume that context 'c' will always be what we expect. Be extra safe and call the method to make sure
            sFoodLab = new FoodLab(context);
        }
        return sFoodLab;
    }

    //Constructor
    private FoodLab(Context context){
        mContext = context.getApplicationContext();
        mDatabase = new FoodBaseHelper(mContext)
                .getWritableDatabase();
    }

    // Add a single Food to the list
    public void addFood(Food c){
        ContentValues values = getContentValues(c);

        mDatabase.insert(FoodDbSchema.FoodTable.NAME, null, values);

    }

    // Delete a single Food to the list
    public void deleteFood(Food m) {
        mDatabase.delete(FoodDbSchema.FoodTable.NAME,
                FoodDbSchema.FoodTable.Cols.UUID + "=?",
                new String[] {m.getId().toString()}
        );
    }

    // Return entire list of foods
    public List<Food> getFood(){
        List<Food> foods = new ArrayList<>();

        FoodCursorWrapper cursor = queryFoods(null, null);

        try {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                foods.add(cursor.getFood());
                cursor.moveToNext();
            }
        }finally {
            cursor.close();
        }

        return foods;
    }
    // Return only a specific food
    public Food getFood(UUID id){

        FoodCursorWrapper cursor = queryFoods(
                FoodDbSchema.FoodTable.Cols.UUID + " = ?",
                new String[]{ id.toString()}
        );

        try{
            if (cursor.getCount()==0){
                return null;
            }

            cursor.moveToFirst();
            return  cursor.getFood();
        } finally {
            cursor.close();
        }
    }

    public File getPhotoFile(Food food){
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, food.getPhotoFilename());
    }

    // Update a single Food to the list
    public void updateFood(Food food){
        String uuidString = food.getId().toString();
        ContentValues values = getContentValues(food);

        mDatabase.update(FoodDbSchema.FoodTable.NAME, values,
                FoodDbSchema.FoodTable.Cols.UUID + " = ?",
                new String[] { uuidString});
    }

    // Save all foods
    private FoodCursorWrapper queryFoods(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                FoodDbSchema.FoodTable.NAME,
                null,
                whereClause,
                whereArgs,
                null,
                null,
                null
        );

        return new FoodCursorWrapper(cursor);
    }

    private static ContentValues getContentValues(Food food){
        ContentValues values = new ContentValues();
        values.put(FoodDbSchema.FoodTable.Cols.UUID, food.getId().toString());
        values.put(FoodDbSchema.FoodTable.Cols.TITLE, food.getTitle());
        values.put(FoodDbSchema.FoodTable.Cols.INFO, food.getInfo());
        values.put(FoodDbSchema.FoodTable.Cols.DATE, food.getDate().getTime());
        values.put(FoodDbSchema.FoodTable.Cols.SOLVED, food.isSolved() ? 1 : 0) ;
        values.put(FoodDbSchema.FoodTable.Cols.SUSPECT, food.getmSuspect()) ;

        return values;
    }
}

