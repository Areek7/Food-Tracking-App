package com.bignerdranch.android.foodtracker;

import java.util.Date;
import java.util.UUID;

public class Food {

    private UUID mId;
    private String mTitle;
    private String mInfo;
    private Date mDate;
    private boolean mSolved;
    private  String mSuspect;

    public Food() {
        // Generate a unique identifier
        this(UUID.randomUUID());
    }

    public Food(UUID id){
        mId = id;
        mDate = new Date();
    }

    public UUID getId() {

        return mId;
    }

    public void setId(UUID id) {
        mId = id;
    }

    public String getTitle() {
        return mTitle;
    }


    public void setTitle(String title) {
        mTitle = title;
    }

    public String getInfo() {
        return mInfo;
    }

    public void setInfo(String info) {
        mInfo = info;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public boolean isSolved() {
        return mSolved;
    }

    public void setSolved(boolean solved) {
        mSolved = solved;
    }

    public String getmSuspect(){
        return mSuspect;
    }

    public void setSuspect(String suspect){
        mSuspect = suspect;
    }

    public String getPhotoFilename(){
        return "IMG_" + getId().toString() + ".jpg";
    }
}

