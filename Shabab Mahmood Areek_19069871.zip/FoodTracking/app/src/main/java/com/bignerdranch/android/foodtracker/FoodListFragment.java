package com.bignerdranch.android.foodtracker;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;



import java.util.List;

public class FoodListFragment extends Fragment {

    private static final String SAVED_SUBTITLE_VISIBLE = "subtitle";

    private RecyclerView mFoodRecyclerView;
    private FoodAdapter mAdapter;
    private boolean mSubtitleVisible;

    @Override
    public void onCreate(Bundle savedInstancedState){
        super.onCreate(savedInstancedState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstancedState){
        // Get view for fragment
        View view = inflater.inflate(R.layout.fragment_food_list, container, false);
        mFoodRecyclerView = (RecyclerView) view.findViewById(R.id.food_recycler_view);
        mFoodRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        if (savedInstancedState != null){
            mSubtitleVisible = savedInstancedState.getBoolean(SAVED_SUBTITLE_VISIBLE);
        }

        updateUI();

        return view;
    }

    @Override
    public void onResume(){
        super.onResume();
        updateUI();
    }

    @Override
    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVED_SUBTITLE_VISIBLE, mSubtitleVisible);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.fragment_food_list, menu);

        MenuItem subtitleItem = menu.findItem(R.id.show_subtitle);
        if(mSubtitleVisible){
            subtitleItem.setTitle(R.string.hide_subtitle);
        }else{
            subtitleItem.setTitle(R.string.show_subtitle);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.new_food:
                Food food = new Food();
                FoodLab.get(getActivity()).addFood(food);
                Intent intent = FoodPagerActivity
                        .newIntent(getActivity(), food.getId());
                startActivity(intent);
                return true;
            case R.id.show_subtitle:
                mSubtitleVisible =!mSubtitleVisible;
                getActivity().invalidateOptionsMenu();
                updateSubtitle();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void updateSubtitle(){
        FoodLab foodLab = FoodLab.get(getActivity());
        int foodCount = foodLab.getFood().size();
        String subtitle = getString(R.string.subtitle_format, foodCount);

        if(!mSubtitleVisible){
            subtitle = null;
        }

        AppCompatActivity activity = (AppCompatActivity) getActivity();
        activity.getSupportActionBar().setSubtitle(subtitle);
    }

    private void updateUI(){
        FoodLab foodLab = FoodLab.get(getActivity());
        List<Food> foods = foodLab.getFood();

        if(mAdapter == null) {
            mAdapter = new FoodAdapter(foods);
            mFoodRecyclerView.setAdapter(mAdapter);
        }else{
            mAdapter.setFoods(foods);
            mAdapter.notifyDataSetChanged();
        }

        updateSubtitle();
    }


    private class FoodHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private TextView mTitleTextView;
        private TextView mInfoTextView;
        private TextView mDateTextView;
        private ImageView mSolvedImageView;
        private Food mFood;


        public void bind(Food food){
            mFood = food;
            mTitleTextView.setText(mFood.getTitle());
            mInfoTextView.setText(mFood.getInfo());
            mDateTextView.setText(mFood.getDate().toString());
            mSolvedImageView.setVisibility(food.isSolved() ? View.VISIBLE : View.GONE);
        }

        public FoodHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_food, parent, false));

            mTitleTextView = (TextView) itemView.findViewById(R.id.food_title);
            mInfoTextView = (TextView) itemView.findViewById(R.id.food_info);
            mDateTextView = (TextView) itemView.findViewById(R.id.food_date);
            mSolvedImageView = (ImageView) itemView.findViewById(R.id.food_solved);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view){
            Intent intent = FoodPagerActivity.newIntent(getActivity(), mFood.getId());
            startActivity(intent);
        }
    }

    private class FoodAdapter extends RecyclerView.Adapter<FoodHolder>{
        private List<Food> mExpens;

        public FoodAdapter(List<Food> expens){

            mExpens = expens;
        }

        @Override
        public FoodHolder onCreateViewHolder(ViewGroup parent, int ViewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new FoodHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(FoodHolder holder, int position){
            Food food = mExpens.get(position);
            holder.bind(food);
        }

        @Override
        public int getItemCount(){
            return mExpens.size();
        }

        public void setFoods(List<Food> expens){
            mExpens = expens;
        }
    }


}

